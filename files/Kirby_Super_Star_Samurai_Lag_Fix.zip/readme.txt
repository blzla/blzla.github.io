=========================================================
 Kirby Super Star Samurai Minigame Lag Compensation Fix
   Author:     blizzz
   Version:    1.0
   Date:       12 April 2022
=========================================================

The Samurai Kirby mini game in Super Star relies solely on reflexes. It
was designed for a zero lag CRT TV. Any input lag through scalers,
emulation and modern digital displays will make this mini game harder.
This hack allows you to compensate for the input lag in your setup.

Press L / R on the difficulty select screen to adjust the amount of
frames. Setting it to 0 will disable the hack.

+1F will give you 16 milliseconds more to react, +2F 32 ms and so on.


Patching Instructions
------------------------------------------------------------------------
Kirby Super Star (USA).sfc - NoIntro (unheadered)
Size: 4.194.304 bytes, CRC32: 89D0F7DC
Apply the patch to the USA version of Kirby Super Star with your
patching tool of choice, for example Flips or the RHDN web patcher.
https://www.romhacking.net/patch/


Credits
------------------------------------------------------------------------
Blizzz: hacking


Version History
------------------------------------------------------------------------
1.0 - 12 April 2022
- Initial release


Contact
------------------------------------------------------------------------
RHDN Forums:
https://www.romhacking.net/forum/index.php?action=profile;u=71746

Twitter: @blizzzilla
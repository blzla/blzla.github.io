=======================================
 Macross Scrambled Valkyrie Plus SRAM
   Author:     blizzz
   Version:    1.0b
   Date:       27 January 2022
=======================================

Macross Scrambled Valkyrie Plus SRAM adds saving for the settings and
your highscore to the game. It also reduces the background scroll speed
in the final level (which can cause nausea) and unlocks level select
once you beat the game on any difficulty.

The game saves automatically after exiting the config menu, beating a
stage or losing a life. Saves are automatically loaded on startup.

The hack includes bidirectional form changing from the Overtech Edition
hack by advancedpillow, used with permission.


Instructions
------------------------------------------------------------------------
ROM info:
Choujikuu Yousai Macross - Scrambled Valkyrie (Japan).sfc (unheadered)
Size: 1048576 bytes, CRC32: A5DB02E9

Apply "Macross Plus SRAM.ips" to the original unpatched
Macross Scrambled Valkyrie rom.

- or -

If you want the Casual difficulty level from the Overtech Edition hack
by advancedpillow, apply the Overtech Edition hack first and then apply
"Macross Plus SRAM for Overtech.ips" on top of it to add SRAM saving.
Casual replaces Easy difficulty.

I recommend using the online rom patcher on RHDN:
https://www.romhacking.net/patch/


Credits
------------------------------------------------------------------------
blizzz - Hacking
Cheesemeister - Original bidirectional change hacking


Thanks
------------------------------------------------------------------------
advancedpillow - Creator of the Overtech Edition hack


Contact
------------------------------------------------------------------------
@blizzzilla on Twitter

RHDN Forums:
https://www.romhacking.net/forum/index.php?action=profile;u=71746

=======================================
 Super Puyo Puyo Offsetting
   Author:     blizzz
   Version:    1.0
   Date:       17 February 2025
=======================================

Despite releasing 9 months before the arcade release of Puyo Puyo Tsū, which
famously added garbage offsetting (Sousai) to the ruleset of the game,
Super Puyo Puyo on the Super Famicom already contained a hidden option to enable
this rule. To access the special menu that contains this option, players had to
enter an Action Replay cheat code (80FFF002) and hold A+B+X+Y on controller 2
while resetting the console.
When Super Puyo Puyo got localized as Kirby's Avalance, the same
hidden menu got carried over to the western release.

This patch enables the full special custom menu and enables offsetting
Garbage Puyos by default.

--------------------------------------------------------------------------------

The two supplied patches are for the US release as well as revision 2 of the
JP release. The JP patch will also work with the other revisions of the rom.

Kirby's Avalanche (USA).sfc
Size: 1048576 bytes, CRC32 21E658B8

Super Puyo Puyo (Japan) (Rev 2).sfc
Size: 1048576 bytes, CRC32 3ADDBA0B

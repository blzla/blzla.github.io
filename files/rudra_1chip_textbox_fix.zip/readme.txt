======================================================
 Treasure of the Rudras Textbox Fix
	version 1.0
	by blizzz, 01.11.2024
======================================================

Rudra no Hihou uses the Super Famicom's 512 pixel mode for its text boxes. Due to bad programming, the game switches modes in the middle of an active scanline, which causes issues on 1CHIP consoles. By moving the mode changes into the H-Blank period the glitches can be fixed.

- Rudra no Hihou 1CHIP Textbox Fix.bps
Apply to the original Japanese version.
Size:	4194304
CRC32:	5d8cb7ac

- Treasure of the Rudras 1CHIP Textbox Fix.bps
Apply to version 2.1(b) of the English fantranslation by Aeon Genesis.
Size:	4194304
CRC32:	2d7bd150

For SD2SNES users: The "1CHIP transient fix" must be turned off.

Known issues:
There's a light gray gradient at the start of the textbox on consoles that have the C11 ghosting fix installed.
